//
//  DemoScreenApp.swift
//  DemoScreen
//
//  Created by Kalidoss Shanmugam on 27/11/22.
//

import SwiftUI

@main
struct DemoScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
